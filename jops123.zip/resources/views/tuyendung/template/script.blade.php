<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->

<script src="{{ asset('asset-uea/js/jquery-1.10.2.js') }}"></script>

<script src="{{ asset('asset-uea/js/ckeditor.js') }}"></script>
<script src="{{ asset('asset-uea/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('asset-uea/js/price_range_script.js') }}"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="{{ asset('asset-uea/js/bootstrap.min.js') }}"></script>
<!-- METISMENU SCRIPTS -->
<script src="{{ asset('asset-uea/js/jquery.metisMenu.js') }}"></script>
<!-- Bootstrap Editor Js -->
<script src="{{ asset('asset-uea/js/wysihtml5-0.3.0.js') }}"></script>
<script src="{{ asset('asset-uea/js/bootstrap-wysihtml5.js') }}"></script>
<!-- Scrollbar Js -->
<script src="{{ asset('asset-uea/js/jquery.slimscroll.js') }}"></script>
<!-- Dropzone Js -->
<script src="{{ asset('asset-uea/js/dropzone.js') }}"></script>
<script src="{{ asset('asset-uea/js/select2.min.js') }}"></script>
<script src="{{ asset('datatable/datatables.min.js') }}"></script>
<!-- CUSTOM SCRIPTS -->
<script src="{{ asset('asset-uea/js/custom.js') }}"></script>