@extends('timviec.template.app')
@section('title','Trang dành cho ứng viên')
@section('content')
    <h1>ksjdhfksdf</h1>
@endsection