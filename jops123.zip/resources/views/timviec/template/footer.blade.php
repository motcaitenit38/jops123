<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1
    </div>
    <strong>©Copyright 2017 <a href="index.html">Job Stock</a>.</strong> All rights reserved.
</footer>