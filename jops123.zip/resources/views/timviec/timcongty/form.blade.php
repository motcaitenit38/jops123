@extends('timviec.template.app')
@section('title','Trang dành cho ứng viên')
@section('content')
    <form action="">
        <input type="text">
        <input type="submit">
    </form>
@endsection