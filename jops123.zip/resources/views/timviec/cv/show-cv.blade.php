@extends('timviec.template.app')
@section('title')
    CV ngành {{ $cvs->career->career_name }}
@endsection
@section('content')

@endsection