<?php

namespace App\Model\Timviec;

use Illuminate\Database\Eloquent\Model;

class TimviecUngtuyen extends Model
{
    //
    protected $table = 'timviec_ungtuyens';
}
