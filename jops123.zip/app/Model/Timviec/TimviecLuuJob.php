<?php

namespace App\Model\Timviec;

use Illuminate\Database\Eloquent\Model;

class TimviecLuuJob extends Model
{
    //
    protected $table = 'timviec_luu_jobs';
}
