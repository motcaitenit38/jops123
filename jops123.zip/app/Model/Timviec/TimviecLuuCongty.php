<?php

namespace App\Model\Timviec;

use Illuminate\Database\Eloquent\Model;

class TimviecLuuCongty extends Model
{
    //
}
