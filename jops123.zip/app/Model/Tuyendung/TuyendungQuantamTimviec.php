<?php

namespace App\Model\Tuyendung;

use Illuminate\Database\Eloquent\Model;

class TuyendungQuantamTimviec extends Model
{
    //
}
